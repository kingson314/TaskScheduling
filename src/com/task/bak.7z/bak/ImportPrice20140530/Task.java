package com.task.ImportPrice20140530;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import module.dbconnection.DbConnection;
import module.dbconnection.DbConnectionDao;

import com.log.Log;
import com.taskInterface.TaskAbstract;

import common.util.jdbc.UtilJDBCManager;
import common.util.jdbc.UtilSql;
import common.util.json.UtilJson;

/**
 * @Description:解析导入，mt4中EA(getData)导出数据格式为bars,timeServer{HHmmss},Ask,Open[0],Close[0],High[0],Low[0],round(ma5,4),round(ma20,4),round(ma60,4),round(kdj,4),Volume[0]
 * @date May 26, 2014
 * @author:fgq
 */
public class Task extends TaskAbstract {
	private static Map<String, Integer> mapFileToDb = new HashMap<String, Integer>();
	private String[] LastLine;

	public void fireTask() {
		Connection con = null;
		PreparedStatement psDetail = null;
		PreparedStatement psMain = null;
		DbConnection dbconn = null;
		BufferedReader buffReader = null;
		String sline = "";
		String[] lineArr = null;
		LastLine = null;
		try {
			Bean bean = (Bean) UtilJson.getJsonBean(this.getParserJsonStr(), Bean.class);
			Log.logInfo("正在导入文件:" + bean.getFilePath());
			dbconn = DbConnectionDao.getInstance().getMapDbConn(bean.getDbName());
			if (dbconn == null) {
				this.setTaskStatus("执行失败");
				this.setTaskMsg("获取文件导入数据库连接错误");
				return;
			}
			con = UtilJDBCManager.getConnection(dbconn);
			if (bean.getFilePath().equals("")) {
				this.setTaskStatus("执行失败");
				this.setTaskMsg("文件路径为空");
				return;
			}

			File inFile = new File(bean.getFilePath());
			if (!inFile.exists()) {
				this.setTaskStatus("执行失败");
				this.setTaskMsg("文件:" + inFile.getAbsolutePath() + " 不存在");
				return;
			}
			String[] insertSqlArr = bean.getInsertSql().split(";");
			String insertSqlDetail = insertSqlArr[0];
			String insertSqlMain = insertSqlArr[1];
			buffReader = new BufferedReader(new InputStreamReader(new FileInputStream(inFile)));
			// buffReader.mark((int) inFile.length() );// 在首行做个标记
			if (mapFileToDb.get(inFile.getName()) == null) {
				// 首次运行，清空
				if (!bean.getDelSql().equals("")) {
					String[] sql = bean.getDelSql().split(";");
					for (int i = 0; i < sql.length; i++) {
						if (sql[i].trim().length() > 1) {
							psDetail = con.prepareStatement(sql[i]);
							psDetail.executeUpdate();
							psDetail.clearBatch();
						}
					}
				}
			} else {
				buffReader.skip(mapFileToDb.get(inFile.getName()));
			}

			mapFileToDb.put(inFile.getName(), (int) inFile.length());
			psDetail = con.prepareStatement(insertSqlDetail, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			psMain = con.prepareStatement(insertSqlMain, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			int cntDetail = 0;
			int cntMain = 0;
			String timeServer = "";
			String dateServer = "";
			int period = Integer.valueOf(bean.getPeriod());
			long bars = 0;
			while ((sline = buffReader.readLine()) != null) {
				try {
					lineArr = sline.split(bean.getSeparate());
					bars = Long.valueOf(lineArr[0]);
					// (Bars,timeServer,dateServer,timeLocal,dateLocal,Ask,Bid,Open[0],Close[0],High[0],Low[0],ma5,ma20,ma60,kdj,Volume[0]);
					// bars,timeServer{HHmmss}, Ask, //
					// Open[0],Close[0],High[0],Low[0],round(ma5,4),round(ma20,4),round(ma60,4),round(kdj,4),Volume[0]
					// 根据周期插入主表数据
					if (LastLine != null) {
						if (bars < Long.valueOf(LastLine[0]))
							break;// 有些文件重复下载了数据
						if (period == 1 || period == 5 || period == 15 || period == 30) {// 分钟制
							timeServer = lineArr[1];
							String minute = timeServer.substring(2,4);
							if (Integer.valueOf(minute) % period == 0) {
								if (!minute.equals(LastLine[1].substring(2, 4))) {
									addBatch(psMain, LastLine);// 主表参数
									cntMain += 1;
								}
							}
						} else if (period == 60 || period == 240) {// 小时制
							timeServer = lineArr[1];
							String hour = timeServer.substring(0, 2);
							if (Integer.valueOf(hour) % (period / 60) == 0) {
								if (!hour.equals(LastLine[1].substring(0, 2))) {
									addBatch(psMain, LastLine);// 主表参数
									cntMain += 1;
								}
							}
						} else if (period == 1440) {// 天制
							dateServer = lineArr[2];
							String day = dateServer.substring(6, 8);
							if (Integer.valueOf(day) % (period / 1440) == 0) {
								if (!day.equals(LastLine[2].substring(6, 8))) {
									addBatch(psMain, LastLine);// 主表参数
									cntMain += 1;
								}
							}
						}
					}
					if (cntMain != 0 && cntMain % 1000 == 0) {
						try {
							psMain.executeBatch();
						} catch (Exception e) {
							continue;
						} finally {
							psMain.clearBatch();
						}
					}
					// =============================================

					LastLine = lineArr.clone();
					addBatch(psDetail, lineArr); // 明细表参数
					cntDetail += 1;
					if (cntDetail != 0 && cntDetail % 1000 == 0) {
						try {
							psDetail.executeBatch();
						} catch (Exception e) {
							continue;
						} finally {
							psDetail.clearBatch();
						}
					}
				} catch (Exception e) {
					Log.logError(sline + "\n", e);
					continue;

				}
			}
			psDetail.executeBatch();

			addBatch(psMain, LastLine);// 补上最后一根可能不够整数周期的
			if (LastLine != null && LastLine.length > 0)
				cntMain += 1;
			psMain.executeBatch();
			this.setTaskStatus("执行成功");
			this.setTaskMsg(bean.getFilePath() + "\n新增明细表记录： " + cntDetail + "   新增主表记录： " + cntMain);
			buffReader.close();
		} catch (Exception e) {
			this.setTaskStatus("执行失败");
			this.setTaskMsg("文件导入错误:", e);
		} finally {
			UtilSql.close(con, psDetail, psMain);
		}
	}

	private void addBatch(PreparedStatement ps, String[] args) throws SQLException {
		if (args == null || args.length <= 0)
			return;
		//使用yyyyMMdd
		String date = this.getNowDate();//this.getNowDate().substring(0, 4) + "." + this.getNowDate().substring(4, 6) + "." + this.getNowDate().substring(6, 8);
		//使用HHmmss
		String time = args[1];//args[1].substring(0, 2) + ":" + args[1].substring(2, 4) + "." + args[1].substring(4, 6);
		ps.setString(1, args[0]);
		ps.setString(2, time);
		ps.setString(3, date);
		ps.setString(4, time);
		ps.setString(5, date);
		ps.setString(6, args[2]);
		ps.setString(7, args[4]);// bid=close
		ps.setString(8, args[3]);
		ps.setString(9, args[4]);
		ps.setString(10, args[5]);
		ps.setString(11, args[6]);
		ps.setString(12, args[7]);
		ps.setString(13, args[8]);
		ps.setString(14, args[9]);
		ps.setString(15, args[10]);
		ps.setString(16, args[11]);
		ps.addBatch();
	}

	public void fireTask(String startTime, String groupId, String scheCod, String taskOrder) {
		fireTask();
	}

}
