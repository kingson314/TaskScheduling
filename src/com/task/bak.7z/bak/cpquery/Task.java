package com.task.cpquery;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Map;
import org.codehaus.jackson.type.TypeReference;
import org.jsoup.Jsoup;
import org.jsoup.Connection.Response;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.html.HtmlAnchor;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.taskInterface.TaskAbstract;
import common.util.conver.UtilConver;
import common.util.file.UtilFile;
import common.util.json.UtilJackSon;

public class Task extends TaskAbstract {
//	private static final String baseDetailUrl = "https://patentscope.wipo.int/search/en/detail.jsf?";
//	private static final String baseSrc = "https://patentscope.wipo.int/search/en/";
	private String filePath;

	public void fireTask() {
		try {
			this.filePath = "d:/tmp/patent"
					+ UtilConver.dateToStr("yyyyMMdd_HHmmss") + ".txt";
			UtilFile.writeFile(this.filePath, UtilConver
					.dateToStr("yyyyMMdd_HHmmss"));
			this.setTaskStatus("执行成功");
			this.setTaskMsg("");
		} catch (Exception e) {
			this.setTaskStatus("执行失败");
			this.setTaskMsg("执行出错:", e);
		} finally {
			System.out.println("done");
		}
	}

	public void fireTask(final String startTime, final String groupId,
			final String scheCod, final String taskOrder) {
		fireTask();
	}
  
	public static void main(String[] args)
			throws FailingHttpStatusCodeException, MalformedURLException,
			IOException {
			long now=System.currentTimeMillis();
//		String sqh="2014100382913";
		//String url="http://patents.stackexchange.com/questions/tagged/US20060007668";
		//String url="https://ggso.in/patents/US20060007668?dq=US20060007668&hl=zh-CN&sa=X&ved=0ahUKEwig_JyAgdTOAhUT22MKHYEWBrgQ6AEIHjAA";
		String url="http://cpquery.sipo.gov.cn/txnQueryBibliographicData.do?select-key:shenqingh=2014108551587";
		HtmlPage page=getSearchPage(url);
//		System.out.println(page.asXml());
		//解析主页
		analysisPage(page);
		System.out.println((System.currentTimeMillis()-now)/1000);
	}

	 
	
	private static HtmlPage getSearchPage(String url) throws FailingHttpStatusCodeException,
			MalformedURLException, IOException {
		/** HtmlUnit请求web页面 */
		WebClient webClient = new WebClient(BrowserVersion.getDefault());
		webClient.addRequestHeader("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		webClient.addRequestHeader("Accept-Encoding", "gzip, deflate, sdch");
		webClient.addRequestHeader("Accept-Language", "zh-CN,zh;q=0.8");
		webClient.addRequestHeader("Cache-Control", "no-cache");
		webClient.addRequestHeader("Connection", "keep-alive");
////	webClient.addRequestHeader("Cookie","_gscu_699342174=71572275mla7yh14; _gscs_699342174=71572275hw483l14|pv:2; _gscu_2029180466=7157220905qo7d91; _gscs_2029180466=71572209p23n5g91|pv:10; _gscu_1718069323=71572208itm8vy15; _gscs_1718069323=71572208uepkw215|pv:22; JSESSIONID=086a6ae593fda4a918c58beaf9b3; bg6149=14|V7ZqE|V7Zom");
////		webClient.addRequestHeader("Host", "cpquery.sipo.gov.cn");//这句话不能加
		webClient.addRequestHeader("Pragma", "no-cache");
		webClient.addRequestHeader("Upgrade-Insecure-Requests:","1");
		webClient.addRequestHeader("User-Agent","Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36");

//		webClient.setJavaScriptEnabled(true);
//		webClient.setActiveXNative(false);
//		webClient.setCssEnabled(false);
//		webClient.setThrowExceptionOnScriptError(false);
//		webClient.waitForBackgroundJavaScript(10* 1000);
//		webClient.setAjaxController(new NicelyResynchronizingAjaxController());
//		String url="http://cpquery.sipo.gov.cn/txnQueryBibliographicData.do?select-key:shenqingh="+params;
		HtmlPage page = webClient.getPage(url);
		return page;
	}
	
	private static void analysisPage(HtmlPage page){
		String html=page.asXml();
		Document doc = Jsoup.parse(html);
		Elements tables= doc.select(".imfor_part1");
		for (Element table:tables){
			System.out.println("-----------table--------------");
			Elements trs=table.select("td");
			for (Element tr:trs){
				Elements span=tr.select("span:eq(0)");
				if( span.size()>0){
					System.out.println( span.attr("title"));
				}else{
					System.out.println(tr.html());
				}
				System.out.println("****************");
			}
			System.out.println("---------------------");
		}
	} 
}
