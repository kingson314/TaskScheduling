//package com.task.patentGov;
//
//import java.io.IOException;
//import java.net.MalformedURLException;
//import java.util.List;
//import java.util.Map;
//import org.codehaus.jackson.type.TypeReference;
//import org.jsoup.Jsoup;
//import org.jsoup.Connection.Response;
//import org.jsoup.nodes.Document;
//import org.jsoup.nodes.Element;
//import org.jsoup.select.Elements;
//import com.gargoylesoftware.htmlunit.BrowserVersion;
//import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
//import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
//import com.gargoylesoftware.htmlunit.WebClient;
//import com.gargoylesoftware.htmlunit.WebResponse;
//import com.gargoylesoftware.htmlunit.html.HtmlAnchor;
//import com.gargoylesoftware.htmlunit.html.HtmlPage;
//import com.taskInterface.TaskAbstract;
//import common.util.conver.UtilConver;
//import common.util.file.UtilFile;
//import common.util.json.UtilJackSon;
//
//public class Task extends TaskAbstract {
////	private static final String baseDetailUrl = "https://patentscope.wipo.int/search/en/detail.jsf?";
////	private static final String baseSrc = "https://patentscope.wipo.int/search/en/";
//	private String filePath;
//
//	public void fireTask() {
//		try {
//			this.filePath = "d:/tmp/patent"
//					+ UtilConver.dateToStr("yyyyMMdd_HHmmss") + ".txt";
//			UtilFile.writeFile(this.filePath, UtilConver
//					.dateToStr("yyyyMMdd_HHmmss"));
//
//			this.setTaskStatus("执行成功");
//			this.setTaskMsg("");
//		} catch (Exception e) {
//			this.setTaskStatus("执行失败");
//			this.setTaskMsg("执行出错:", e);
//		} finally {
//			System.out.println("done");
//		}
//
//	}
//
//	public void fireTask(final String startTime, final String groupId,
//			final String scheCod, final String taskOrder) {
//		fireTask();
//	}
//
//	/**
//	 * 执行一个HTTP POST请求，返回请求响应的HTML
//	 * 
//	 * @param url
//	 *            请求的URL地址
//	 * @param params
//	 *            请求的查询参数,可以为null
//	 * @param charset
//	 *            字符集
//	 * @param pretty
//	 *            是否美化
//	 * @return 返回请求响应的HTML
//	 */
////	public static String doPost(String url, Map<String, String> params,
////			String charset, boolean pretty) {
////		StringBuffer response = new StringBuffer();
////		HttpClient client = new HttpClient();
////		
////		HttpMethod method = new PostMethod(url);
////		method.addRequestHeader("Accept","application/json, text/javascript, */*; q=0.01");
////		method.addRequestHeader("Accept-Encoding", "gzip, deflate");
////		method.addRequestHeader("Accept-Language", "zh-CN,zh;q=0.8");
////		method.addRequestHeader("Cache-Control", "no-cache");
////		method.addRequestHeader("Connection", "keep-alive");
////		method.addRequestHeader("Content-Length", "93");
////		method.addRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
////		method.addRequestHeader("Host", "www.pss-system.gov.cn");
////		method.addRequestHeader("Origin", "http://www.pss-system.gov.cn");
////		method.addRequestHeader("Referer","http://www.pss-system.gov.cn/sipopublicsearch/portal/uiIndex.shtml?searchExpFromIndex=CN201510118179");
////		method.addRequestHeader("Pragma", "no-cache");
////		method.addRequestHeader("Cookie","WEE_SID=k8ghXzhR9sl508kLmyvv35nvySfpK1PmLxjHyHz1yVsHzvR9PCsj!-962131241!-311642201!1471390033084; IS_LOGIN=false; wee_username=ZmVuZ2d1b3F1; wee_password=S2luZ3NvbjAwMA%3D%3D; avoid_declare=declare_pass; JSESSIONID=k8ghXzhR9sl508kLmyvv35nvySfpK1PmLxjHyHz1yVsHzvR9PCsj!-962131241!-311642201; _gscu_761734625=69669911yui9je23; _gscs_761734625=t71398586xdvm5296|pv:8; _gscbrs_761734625=1");
////		method.addRequestHeader("X-Requested-With", "XMLHttpRequest");
////		method.addRequestHeader("User-Agent","Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36");
////		// 设置Http Post数据
////		if (params != null) {
////			HttpMethodParams p = new HttpMethodParams();
////			for (Map.Entry<String, String> entry : params.entrySet()) {
////				p.setParameter(entry.getKey(), entry.getValue());
////			}
////			method.setParams(p);
////		}
////		try {
////			client.executeMethod(method);
////			if (method.getStatusCode() == HttpStatus.SC_OK) {
////				System.out.println(method.getResponseBodyAsString());
//////				BufferedReader reader = new BufferedReader(new InputStreamReader(method.getResponseBodyAsStream(),charset));
//////				String line;
//////				while ((line = reader.readLine()) != null) {
//////					if (pretty)
//////						response.append(line).append(
//////								System.getProperty("line.separator"));
//////					else
//////						response.append(line);
//////				}
//////				reader.close();
////			}
////		} catch (IOException e) {
////			e.printStackTrace();
////		} finally {
////			method.releaseConnection();
////		}
////		return response.toString();
////	}
//	   /**
//     * 接口调用  POST
//     */
////    public static void httpURLConnectionPOST (String POST_URL) {
////        try {
////        	POST_URL="http://www.pss-system.gov.cn/sipopublicsearch/portal/paramRewriter-paramEncode.shtml";
////            URL url = new URL(POST_URL);
////            // 将url 以 open方法返回的urlConnection  连接强转为HttpURLConnection连接  (标识一个url所引用的远程对象连接)
////            HttpURLConnection connection = (HttpURLConnection) url.openConnection();// 此时cnnection只是为一个连接对象,待连接中
////            // 设置连接输出流为true,默认false (post 请求是以流的方式隐式的传递参数)
////            connection.setDoOutput(true);
////            // 设置连接输入流为true
////            connection.setDoInput(true);
////            // 设置请求方式为post
////            connection.setRequestMethod("POST");
////            // post请求缓存设为false
////            connection.setUseCaches(false);
////            // 设置该HttpURLConnection实例是否自动执行重定向
////            connection.setInstanceFollowRedirects(true);
////            // 设置请求头里面的各个属性 (以下为设置内容的类型,设置为经过urlEncoded编码过的from参数)
////            // application/x-javascript text/xml->xml数据 application/x-javascript->json对象 application/x-www-form-urlencoded->表单数据
////            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
////            // 建立连接 (请求未开始,直到connection.getInputStream()方法调用时才发起,以上各个参数设置需在此方法之前进行)
////            connection.connect();
////            // 创建输入输出流,用于往连接里面输出携带的参数,(输出内容为?后面的内容)
////            DataOutputStream dataout = new DataOutputStream(connection.getOutputStream());
//////            String parm = "storeId=" + URLEncoder.encode("32", "utf-8"); //URLEncoder.encode()方法  为字符串进行编码
////            String parm="searchExpFromIndex=CN201510118179&searchCondition_scope&searchCondition_type=AI";
////            // 将参数输出到连接
////            dataout.writeBytes(parm);
////            // 输出完成后刷新并关闭流
////            dataout.flush();
////            dataout.close(); // 重要且易忽略步骤 (关闭流,切记!) 
//////            System.out.println(connection.getResponseCode());
////            // 连接发起请求,处理服务器响应  (从连接获取到输入流并包装为bufferedReader)
////            BufferedReader bf = new BufferedReader(new InputStreamReader(connection.getInputStream())); 
////            String line;
////            StringBuilder sb = new StringBuilder(); // 用来存储响应数据
////            // 循环读取流,若不到结尾处
////            while ((line = bf.readLine()) != null) {
////                sb.append(bf.readLine());
////            }
////            bf.close();    // 重要且易忽略步骤 (关闭流,切记!) 
////            connection.disconnect(); // 销毁连接
////            System.out.println(sb.toString());
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////    }
//     
//	private static void bak() throws FailingHttpStatusCodeException, MalformedURLException, IOException{
//		WebClient webClient = new WebClient(BrowserVersion.getDefault());
//		webClient.addRequestHeader("Accept","application/json,text/javascript, */*; q=0.01");
//		webClient.addRequestHeader("Accept-Encoding", "gzip, deflate");
//		webClient.addRequestHeader("Accept-Language", "zh-CN,zh;q=0.8");
//		webClient.addRequestHeader("Cache-Control", "no-cache");
//		webClient.addRequestHeader("Connection", "keep-alive");
////		webClient.addRequestHeader("Content-Length", "93");
//		webClient.addRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
//		webClient.addRequestHeader("Cookie","WEE_SID=pTHTX0phB9fpTvvGmVCHK8nGvlc2qhM8PQVFpyJDqP3SF4kQjyBl!263245991!-210078409!1471474010695; IS_LOGIN=true; wee_username=ZmVuZ2d1b3F1; wee_password=S2luZ3NvbjAwMA%3D%3D; avoid_declare=declare_pass; JSESSIONID=pTHTX0phB9fpTvvGmVCHK8nGvlc2qhM8PQVFpyJDqP3SF4kQjyBl!263245991!-210078409; _gscu_761734625=69669911yui9je23; _gscs_761734625=t714821733ukl5i22|pv:3; _gscbrs_761734625=1");
//		webClient.addRequestHeader("Host", "www.pss-system.gov.cn");
//		webClient.addRequestHeader("Origin", "http://www.pss-system.gov.cn");
//		webClient.addRequestHeader("Pragma", "no-cache");
//		webClient.addRequestHeader("Referer","http://www.pss-system.gov.cn/sipopublicsearch/portal/uiIndex.shtml?searchExpFromIndex=CN201510118179");
//		webClient.addRequestHeader("User-Agent","Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36");
//		webClient.addRequestHeader("X-Requested-With", "XMLHttpRequest");
////		webClient.setJavaScriptEnabled(false);
////		webClient.setActiveXNative(false);
////		webClient.setCssEnabled(false);
////		webClient.setThrowExceptionOnScriptError(false);
////		webClient.waitForBackgroundJavaScript(600 * 1000);
////		webClient.setAjaxController(new NicelyResynchronizingAjaxController());
//		HtmlPage page = webClient.getPage("http://www.pss-system.gov.cn/sipopublicsearch/portal/paramRewriter-paramEncode.shtml?params=searchExpFromIndex=CN201510118179@==@searchCondition_scope=@==@searchCondition_type=AI");
//		WebResponse response = page.getWebResponse();
//		String json = response.getContentAsString();
//		System.out.println(json);
////		System.out.println(page.asText());
//		// final HtmlAnchor button = (HtmlAnchor)
//		// page.getElementById("quickSearch");
//		// final HtmlTextInput textField = (HtmlTextInput)
//		// page.getElementById("quickInput");
//		// textField.setValueAttribute("CN201510118179");//CN201510118179
//		// final HtmlPage pageSearch = button.click();
//		// webClient.waitForBackgroundJavaScript(1000*10);
//		// System.out.println(pageSearch.asXml());
//		// String pageXml = page.asXml(); //以xml的形式获取响应文本
//		// HtmlAnchor anchor=(HtmlAnchor)
//		// page.getElementById("abstractTitleId").getFirstChild();
//		// HtmlPage page1 = anchor.click();
//		// webClient.waitForBackgroundJavaScript(1000*10);
//		// /**jsoup解析文档*/
//		// Document doc = Jsoup.parse(pageXml);
//		// Element pv = doc.select("#feed_content span").get(1);
//		// System.out.println(pv.text());
//		// Assert.assertTrue(pv.text().contains("浏览"));
//		// System.out.println(page1.asXml());
//	}
//	
//	public static void main(String[] args)
//			throws FailingHttpStatusCodeException, MalformedURLException,
//			IOException {
//		String sqh="CN201310281959.2";//黎丽红
////		sqh="CN201420051438.8"; //裴小明 曹宇星
////		sqh="CN201510890969.5"; //李云祥 常迪 李静伟
//		sqh="CN103349438A";
//		String params=getSearchParam(sqh);		
//		HtmlPage page=getSearchPage(params);
//		
//		//解析主页
//		analysisPage(page);
//	}
//
//	private static  String getSearchParam(String sqh) throws IOException{
//		String url="http://www.pss-system.gov.cn/sipopublicsearch/portal/paramRewriter-paramEncode.shtml";
//		org.jsoup.Connection conn =  Jsoup.connect(url).timeout(20000).ignoreContentType(true);;
//		conn.data("params","searchExpFromIndex="+sqh+"@==@searchCondition_scope=@==@searchCondition_type=AI");
//		conn.header("Accept","application/json,text/javascript, */*; q=0.01");
//		conn.header("Accept-Encoding", "gzip, deflate");
//		conn.header("Accept-Language", "zh-CN,zh;q=0.8");
//		conn.header("Cache-Control", "no-cache");
//		conn.header("Connection", "keep-alive");
//		conn.header("Content-Length", "93");
//		conn.header("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
////		conn.header("Cookie","WEE_SID=k8ghXzhR9sl508kLmyvv35nvySfpK1PmLxjHyHz1yVsHzvR9PCsj!-962131241!-311642201!1471390033084; IS_LOGIN=false; wee_username=ZmVuZ2d1b3F1; wee_password=S2luZ3NvbjAwMA%3D%3D; avoid_declare=declare_pass; JSESSIONID=k8ghXzhR9sl508kLmyvv35nvySfpK1PmLxjHyHz1yVsHzvR9PCsj!-962131241!-311642201; _gscu_761734625=69669911yui9je23; _gscs_761734625=t71398586xdvm5296|pv:8; _gscbrs_761734625=1");
//		conn.header("Host", "www.pss-system.gov.cn");
//		conn.header("Origin", "http://www.pss-system.gov.cn");
//		conn.header("Pragma", "no-cache");
////		conn.header("Referer","http://www.pss-system.gov.cn/sipopublicsearch/portal/uiIndex.shtml?searchExpFromIndex=CN201310281959.2");
//		conn.header("User-Agent","Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36");
//		conn.header("X-Requested-With", "XMLHttpRequest");
//		Response rs = conn.execute();
//		Map<String,String> map=UtilJackSon.toObj(rs.body(),new TypeReference<Map<String,String>>() {});
//		System.out.println(map.get("params"));
//		return map.get("params");
//	}
//	
//	private static HtmlPage getSearchPage(String params) throws FailingHttpStatusCodeException,
//			MalformedURLException, IOException {
//		/** HtmlUnit请求web页面 */
//		WebClient webClient = new WebClient(BrowserVersion.getDefault());
//		webClient.addRequestHeader("Accept","*/*");
//		webClient.addRequestHeader("Accept-Encoding", "gzip, deflate");
//		webClient.addRequestHeader("Accept-Language", "zh-CN,zh;q=0.8");
//		webClient.addRequestHeader("Cache-Control", "no-cache");
//		webClient.addRequestHeader("Connection", "keep-alive");
//		webClient.addRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
////		webClient.addRequestHeader("Cookie","WEE_SID=pTHTX0phB9fpTvvGmVCHK8nGvlc2qhM8PQVFpyJDqP3SF4kQjyBl!263245991!-210078409!1471474010695; IS_LOGIN=true; wee_username=ZmVuZ2d1b3F1; wee_password=S2luZ3NvbjAwMA%3D%3D; avoid_declare=declare_pass; JSESSIONID=pTHTX0phB9fpTvvGmVCHK8nGvlc2qhM8PQVFpyJDqP3SF4kQjyBl!263245991!-210078409; _gscu_761734625=69669911yui9je23; _gscs_761734625=t714821733ukl5i22|pv:5; _gscbrs_761734625=1");
//////		webClient.addRequestHeader("Host", "www.pss-system.gov.cn");//这句话不能加
//		webClient.addRequestHeader("Origin", "http://www.pss-system.gov.cn");
//		webClient.addRequestHeader("Pragma", "no-cache");
////		webClient.addRequestHeader("Referer","http://www.pss-system.gov.cn/sipopublicsearch/patentsearch/searchHomeIndex-searchHomeIndex.shtml?params=4C3F74C3281B65A97F2870FF32DEFA09A83706DD04F50CE964E4613AEA63298BE7DDC3500393ACC27FB259D3EC30A8243AA6B1E84B6357739CEFFF6682D55D5876324C8B6E7F92194FB51ED4A59ED89D5A8C115EA4061AF4");
//		webClient.addRequestHeader("User-Agent","Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36");
//
//		webClient.setActiveXNative(false);
//		webClient.setCssEnabled(false);
//		webClient.setThrowExceptionOnScriptError(false);
//		webClient.waitForBackgroundJavaScript(5 * 1000);
//		webClient.setAjaxController(new NicelyResynchronizingAjaxController());
//		String url="http://www.pss-system.gov.cn/sipopublicsearch/patentsearch/searchHomeIndex-searchHomeIndex.shtml?"+params;
//		HtmlPage page = webClient.getPage(url);
//		webClient.waitForBackgroundJavaScript(1000 * 10);
//		List<HtmlAnchor> list =page.getAnchors();
//		for(HtmlAnchor anchor:list){
//			if("lawState".equals(anchor.getAttribute("role"))){
//				System.out.println(anchor.asXml());
//
//				//解析主页上法律状态按钮获取页面
//				analysislawState(webClient,anchor);
//			}
//		}
//		System.out.println("_________________");
//		return page;
//	}
//	
//	private static void analysisPage(HtmlPage page){
//		String html=page.asXml();
//		Document doc = Jsoup.parse(html);
//		Elements elements = doc.select("p");
//		for (Element ele:elements){
//			String span=ele.html();
//			System.out.println(span);
//		}
//		
//	}
//	
//	private static void analysislawState(WebClient webClient,HtmlAnchor anchor) throws IOException{
//		 final HtmlPage page = anchor.click();
//		 webClient.waitForBackgroundJavaScript(1000 * 10);
//		 System.out.println(page.asXml());
//	}
//}
