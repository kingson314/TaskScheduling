package com.task.patentGov;

import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import common.util.conver.UtilConver;

public class TaskEconomic{

	public static void main1(String[] args) {
		String html="<img src=\"http://img.kuaixun360.com/state/rb.png\" alt=\"日本\"/\">";
		Document doc=Jsoup.parse(html);
//		System.out.println(doc.html());
		Elements elements = doc.select("img");
		for(Element ele:elements){
			System.out.println(ele.text());
			System.out.println(ele.attr("src"));
			System.out.println(ele.attr("alt"));
		}
	}
	public static void main(String[] args) throws IOException {
		String pulishDate="2016-11-04";
		String url="http://www.kxt.com/cjrl/ajax?date="+pulishDate;
		org.jsoup.Connection conn =  Jsoup.connect(url).timeout(20000).ignoreContentType(true);
		conn.header("Accept", "application/json, text/javascript, */*; q=0.01");
		conn.header("Accept-Encoding", "gzip, deflate, sdch");
		conn.header("Accept-Language", "zh-CN,zh;q=0.8,en;q=0.6");
		conn.header("Cache-Control", "no-cache");
		conn.header("Connection", "keep-alive");
		conn.header("Cookie", "aliyungf_tc=AQAAAO8RIx2MKQcAOnxqcYgJaQnchikR; PHPSESSID=srmfnb0ou7n2ct2bulim3ung16; BAIDU_SSP_lcr=https://www.baidu.com/link?url=heT8Jm5G21sTRGuskm5QAlDdnzO5wP1hoWaiZtIzBde&wd=&eqid=f4b54bb100005977000000065823c95f; inotic=1; isound=1; selectPro=%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdt%3E%E6%95%B0%E6%8D%AE%E7%B1%BB%E5%88%AB%EF%BC%9A%3C%2Fdt%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdd%20class%3D%22on%22%3E%E9%87%91%E9%93%B6%3C%2Fdd%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdd%20class%3D%22on%22%3E%E7%9F%B3%E6%B2%B9%3C%2Fdd%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdd%20class%3D%22on%22%3E%E5%A4%96%E6%B1%87%3C%2Fdd%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20; selectImp=%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdt%3E%E9%87%8D%E8%A6%81%E6%80%A7%EF%BC%9A%3C%2Fdt%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdd%20class%3D%22on%22%3E%E9%AB%98%3C%2Fdd%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdd%20class%3D%22on%22%3E%E4%B8%AD%3C%2Fdd%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdd%20class%3D%22%22%3E%E4%BD%8E%3C%2Fdd%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20; qVHu$u9gFfh2OsWxLoh5GZ1t=fbiyZLJ3mpV_e36sg77WnJN9s5XFq3CsxtGl05SQZZ9_zaugx3uJ3IGjqKiNqZxmlmjE2sOYn2av0YfblYx6qXnSq53FinCVjI1qmo-ttax7n9DOr7l8sK_OftyBomWufc6yprGHns5-entilr2Un3uf0N2wqZpqsd6K3ICzemeWtZ5u; jumpUrl=%2Frili; CNZZDATA1255358964=476461913-1478738872-null%7C1478738872; Hm_lvt_914d75ee2c3512219b999cc5ce43eac9=1478740326; Hm_lpvt_914d75ee2c3512219b999cc5ce43eac9=1478740950");
		conn.header("Host", "www.kxt.com");
		conn.header("Referer", "http://www.kxt.com/rili");
		conn.header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36");
		conn.header("X-Requested-With", "XMLHttpRequest");
		conn.header("Pragma", "no-cache");
		Document doc = conn.get();

//		System.out.println(doc.html());
		String html=doc.html().replace("&gt;", ">").replace("&lt;", "<").replace("&quot;", "\"").replace(" </tr>", "</tr><tr>");
		html=UtilConver.decodeUnicode(html);
//		html=html.substring(html.indexOf("cjDataHtml"));
		int  indexEconomic=html.indexOf("cjDataHtml");
		int  indexHoliday=html.indexOf("jiaqiHtml");
		int  indexEvent=html.indexOf("dashiHtml");
		int  indexDate=html.indexOf("dateHtml");
		String htmlEconomic=html.substring(indexEconomic,indexHoliday).replace("\"\"", "\"");
		String[] htmlEconomicArr=htmlEconomic.split("</tr>");
		for(int i=1;i<htmlEconomicArr.length;i++){
			String[] economicArr=htmlEconomicArr[i].split("</td>");
//			System.out.println(htmlEconomicArr[i]);
			for(int j=0;j<economicArr.length;j++){
				System.out.print(economicArr[j].trim()+"|");
			}
			System.out.println();
		}
		
//		if(1==1)return;
		
//		System.out.println(htmlEconomic);
//		System.out.println("------------------------------------------");
		String htmlHoliday=html.substring(indexHoliday,indexEvent).replace("\"\"", "\"");
//		System.out.println(htmlHoliday);
//		System.out.println("------------------------------------------");
		String htmlEvent=html.substring(indexEvent,indexDate).replace("\"\"", "\"");
//		System.out.println(htmlEvent); 
		
		String htmlOther=html.substring(indexDate).replace("\"\"", "\"");
//		System.out.println(htmlOther);
//		doc = Jsoup.parse(html);
//		Elements elements = doc.select("tr");
//		for(Element ele:elements){
//			System.out.println(ele.text());
//		}
	}
}
