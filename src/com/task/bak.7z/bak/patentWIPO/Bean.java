package com.task.patentWIPO;

public class Bean {
	private String dbName;
	private int begPageIndex;// 开始页码
	private int endPageIndex;// 结束页码

	public String getDbName() {
		return dbName;
	}

	public void setDbName(String dbName) {
		this.dbName = dbName;
	}

	public int getBegPageIndex() {
		return begPageIndex;
	}

	public void setBegPageIndex(int begPageIndex) {
		this.begPageIndex = begPageIndex;
	}

	public int getEndPageIndex() {
		return endPageIndex;
	}

	public void setEndPageIndex(int endPageIndex) {
		this.endPageIndex = endPageIndex;
	}
}
