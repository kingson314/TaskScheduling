package com.task.patentWIPO;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import net.sf.json.JSONObject;
import com.app.AppFun;
import com.log.Log;
import com.taskInterface.ITask;
import com.taskInterface.ITaskPanel;
import common.component.ShowMsg;
import common.util.string.UtilString;
import consts.Const;

public class Panel implements ITaskPanel {
	private static final long serialVersionUID = 1L;
	private JPanel pnl;
	private JLabel lDbName;
	private JTextField txtDbName;
	private JButton btnDbName;
	private JLabel lBegPageIndex;
	private JTextField txtBegPageIndex;
	private JLabel lEndPageIndex;
	private JTextField txtEndPageIndex;


	public JPanel getPanel() {
		pnl = new JPanel();
		try {
			pnl.setLayout(null);
			pnl.setBounds(-13, 13, 626, 43);
			pnl.setBorder(BorderFactory.createTitledBorder(""));
			pnl.setPreferredSize(new java.awt.Dimension(668, 482));
			pnl.setSize(429, 95);
			{
				lDbName = new JLabel();
				pnl.add(lDbName);
				lDbName.setText("\u6570\u636e\u5e93\u8fde\u63a5");
				lDbName.setBounds(21, 81, 70, 14);
				lDbName.setFont(Const.tfont);
			}
			{
				txtDbName = new JTextField();
				pnl.add(txtDbName);
				txtDbName.setBounds(103, 81, 429, 21);
				txtDbName.addMouseListener(new MouseAdapter() {
					public void mouseClicked(MouseEvent e) {
						if (e.getClickCount() == 2)
							btnDbName();
					}
				});
			}
			{
				btnDbName = new JButton();
				pnl.add(btnDbName);
				btnDbName.setText("..");
				btnDbName.setBounds(538, 81, 22, 21);
				btnDbName.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent evt) {
						btnDbName();
					}
				});
			}
			{
				lBegPageIndex = new JLabel();
				pnl.add(lBegPageIndex);
				lBegPageIndex.setText("开始页码");
				lBegPageIndex.setBounds(21, 140, 67, 14);
				lBegPageIndex.setFont(Const.tfont);
			}
			{
				txtBegPageIndex = new JTextField();
				pnl.add(txtBegPageIndex);
				txtBegPageIndex.setText("1");
				txtBegPageIndex.setBounds(80, 140, 100, 21);
				txtBegPageIndex.setFont(Const.tfont);
			}
			
			{
				lEndPageIndex = new JLabel();
				pnl.add(lEndPageIndex);
				lEndPageIndex.setText("结束页码");
				lEndPageIndex.setBounds(220, 140, 67, 14);
				lEndPageIndex.setFont(Const.tfont);
			}
			{
				txtEndPageIndex = new JTextField();
				pnl.add(txtEndPageIndex);
				txtEndPageIndex.setText("1");
				txtEndPageIndex.setBounds(295, 140, 100, 21);
				txtEndPageIndex.setFont(Const.tfont);
			}
		 
		} catch (Exception e) {
			Log.logError("构造错误:", e);
			return pnl;
		} finally {
		}
		return pnl;
	}

	// 参数验证
	private boolean paramValidate(Bean bean) {
		if ("".equals(bean.getDbName())) {
			ShowMsg.showWarn("数据源连接不能为空");
			return false;
		} else if ("".equals(bean.getBegPageIndex())) {
			ShowMsg.showWarn("开始页码不能为空");
			return false;
		} else if ("".equals(bean.getEndPageIndex())) {
			ShowMsg.showWarn("结束页码不能为空");
			return false;
		}  
		return true;
	}

	public boolean fillTask(ITask task) {
		try {
			Bean bean = new Bean();
			bean.setDbName(UtilString.isNil(txtDbName.getText()));
			bean.setBegPageIndex(Integer.valueOf(UtilString.isNil(txtBegPageIndex.getText())));
			bean.setEndPageIndex(Integer.valueOf(UtilString.isNil(txtEndPageIndex.getText())));
			if (!paramValidate(bean))
				return false;
			task.setJsonStr(JSONObject.fromObject(bean).toString());
		} catch (Exception e) {
			Log.logError("赋值任务对象错误:", e);
			return false;
		} finally {
		}
		return true;
	}

	public void fillComp(ITask task) {
		try {
			Bean bean = (Bean) JSONObject.toBean(JSONObject.fromObject(task.getJsonStr()), Bean.class);
			txtDbName.setText(bean.getDbName());
			txtBegPageIndex.setText(String.valueOf(bean.getBegPageIndex()));
			txtEndPageIndex.setText(String.valueOf(bean.getEndPageIndex()));
		} catch (Exception e) {
			Log.logError("填充控件错误:", e);
		} finally {
		}
	}

	private void btnDbName() {
		try {
			AppFun.getDbName(txtDbName);
		} catch (Exception e) {
			Log.logError("获取数据源链接错误:", e);
		} finally {
		}
	}

	 

	private JLabel getLblFilePath() {
		if (lEndPageIndex == null) {
			lEndPageIndex = new JLabel();
			lEndPageIndex.setText("\u6587\u4ef6\u8def\u5f84");
			lEndPageIndex.setFont(Const.tfont);
			lEndPageIndex.setBounds(21, 36, 60, 14);
		}
		return lEndPageIndex;
	}

}
