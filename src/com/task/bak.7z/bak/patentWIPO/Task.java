package com.task.patentWIPO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import module.dbconnection.DbConnection;
import module.dbconnection.DbConnectionDao;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.task.patentWIPO.patent.PatentWIPO;
import com.taskInterface.TaskAbstract;
import common.util.conver.UtilConver;
import common.util.file.UtilFile;
import common.util.jdbc.UtilJDBCManager;
import common.util.jdbc.UtilSql;
import common.util.json.UtilJson;

public class Task extends TaskAbstract {
	private static final String baseDetailUrl="https://patentscope.wipo.int/search/en/detail.jsf?";
	private static final String baseSrc="https://patentscope.wipo.int/search/en/";
	private String filePath;
	public void fireTask() {
		try {
			this.filePath="d:/tmp/patent"+UtilConver.dateToStr("yyyyMMdd_HHmmss")+".txt";
			UtilFile.writeFile(this.filePath,UtilConver.dateToStr("yyyyMMdd_HHmmss"));
			Bean bean = (Bean) UtilJson.getJsonBean(this.getParserJsonStr(), Bean.class);
			//step1:根据页码获取查询专利列表的URL
 			for(int i=bean.getBegPageIndex();i<=bean.getEndPageIndex();i++){
 				String list_Url=null;
				list_Url=this.getListUrl(i);
 				System.out.println("第"+i+"页:"+list_Url);
				//step1:根据页码获取查询专利列表的URL
 				List<String>listHref=null;
 				try{
 	 				listHref=this.getListHref(list_Url);
 				}catch(Exception e1){
 					UtilFile.writeFile(this.filePath,UtilFile.readFile(this.filePath)+"读取专利列表所在页报错："+String.valueOf(i));
 					continue;
 				}
 				if(listHref.size()<=0){
 					UtilFile.writeFile(this.filePath,UtilFile.readFile(this.filePath)+"读取专利列表获取不到专利明细页："+String.valueOf(i));
 				}
				//step2:在专利列表中获取detail的href列表
				for(String href:listHref){
					//step3:获取detail专利信息
					String detailUrl=this.baseDetailUrl+href;
					PatentWIPO patent=this.getPatent(detailUrl);
					//step4:插入数据库
					if(patent!=null){
						this.insertDb(bean.getDbName(), patent);
					}else{
						UtilFile.writeFile(this.filePath,UtilFile.readFile(this.filePath)+"单个专利错误所在页报错："+String.valueOf(i));
					}
					Thread.sleep(1500);
				}
				Thread.sleep(1500);
			}
			this.setTaskStatus("执行成功");
			this.setTaskMsg("");
		} catch (Exception e) {
			this.setTaskStatus("执行失败");
			this.setTaskMsg("执行出错:", e);
		} finally {
			System.out.println("done");
		}

	}

	
	//step1:根据页码获取查询专利列表的URL
	private static String getListUrl(int pageIndex){
		return "https://patentscope.wipo.int/search/en/result.jsf?currentNavigationRow="+pageIndex+"&prevCurrentNavigationRow="+(pageIndex-1)+"&query=&office=&sortOption=Pub%20Date%20Desc&prevFilter=&maxRec=56518959&viewOption=All";
	}
	
	//step2:在专利列表中获取detail的href列表
	private List<String> getListHref(String url) throws IOException{
		List<String> list=new ArrayList<String>();
		Document doc= getDoc(url);
		Elements elements = doc.select("a[id*=resultTable]");
//			System.out.println(doc.html());
		for (Element ele:elements){
			String href=ele.attr("href");
			if(href.trim().length()>0){
				list.add(href.substring(href.indexOf("docId")));
			}
		}
		return list;
	}
	private Document getDoc(String url) throws IOException{
		org.jsoup.Connection conn =  Jsoup.connect(url).timeout(20000);
		//.ignoreContentType(true);
		conn.header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		conn.header("Accept-Encoding", "gzip, deflate, sdch, br");
		conn.header("Accept-Language", "zh-CN,zh;q=0.8,en;q=0.6");
		//conn.header("Cache-Control", "max-age=0");
		conn.header("Connection", "keep-alive");
		conn.header("Cookie", "JSESSIONID=F436CB7B78674F2309DE4A594814ACDE.wapp2nC");
		conn.header("Host", "patentscope.wipo.int");
		conn.header("Referer", "https://patentscope.wipo.int/search/en/result.jsf");
		conn.header("Upgrade-Insecure-Requests", "1");
		conn.header("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2767.5 Safari/537.36");
		Document doc = conn.get();
		return doc;
	}
	//step3:获取detail专利信息
	private PatentWIPO getPatent(String url){
		PatentWIPO patent=new PatentWIPO();
		try {
			Document doc= getDoc(url);
			System.out.println(url);
			Elements elements = doc.select("[id$=NationalBiblio]").select(".alignTop");
			for(Element ele:elements){
				String line=ele.text();
				System.out.println(line);
				if(line.indexOf("PCT Reference:")>=0){
					patent.setPCTReference(line.substring(line.indexOf("PCT Reference:")+"PCT Reference:".length()).trim());
				}else if(line.indexOf("Application Number:")>=0){
					patent.setApplicationNumber(line.substring(line.indexOf("Application Number:")+"Application Number:".length(),line.indexOf("Application Date:")).trim());
					patent.setApplicationDate(line.substring(line.indexOf("Application Date:")+"Application Date:".length()).trim());
				}else if(line.indexOf("Publication Number:")>=0){
					patent.setPublicationNumber(line.substring(line.indexOf("Publication Number:")+"Publication Number:".length(),line.indexOf("Publication Date:")).trim());
					patent.setPublicationDate(line.substring(line.indexOf("Publication Date:")+"Publication Date:".length()).trim());
				}else if(line.indexOf("Grant Number:")>=0){
					patent.setGrantNumber(line.substring(line.indexOf("Grant Number:")+"Grant Number:".length(),line.indexOf("Grant Date:")).trim());
					patent.setGrantDate(line.substring(line.indexOf("Grant Date:")+"Grant Date:".length()).trim());
				}else if(line.indexOf("Publication Kind :")>=0){
					patent.setPublicationKind(line.substring(line.indexOf("Publication Kind :")+"Publication Kind :".length()).trim());
				}else if(line.indexOf("Applicants:")>=0){
					patent.setApplicants(line.substring(line.indexOf("Applicants:")+"Applicants:".length()).trim());
				}else if(line.indexOf("Inventors:")>=0){
					patent.setInventors(line.substring(line.indexOf("Inventors:")+"Inventors:".length()).trim());
				}else if(line.indexOf("Priority Data:")>=0){
					patent.setPriorityData(line.substring(line.indexOf("Priority Data:")+"Priority Data:".length()).trim());
				}else if(line.indexOf("Title:")>=0){
					patent.setTitle(line.substring(line.indexOf("Title:")+"Title:".length()).trim());
				}else if(line.indexOf("Abstract:")>=0){
					patent.setMemo(line.substring(line.indexOf("Abstract:")+"Abstract:".length()).trim());
				}else if(line.indexOf("PCT Reference:")>=0){
					patent.setPCTReference(line.substring(line.indexOf("PCT Reference:")+"PCT Reference:".length()).trim());
				}else if(line.indexOf("申请号:")>=0){
					patent.setApplicationNumber(line.substring(line.indexOf("申请号:")+"申请号:".length(),line.indexOf("申请日:")).trim());
					patent.setApplicationDate(line.substring(line.indexOf("申请日:")+"申请日:".length()).trim());
				}else if(line.indexOf("公布号:")>=0){
					patent.setPublicationNumber(line.substring(line.indexOf("公布号:")+"公布号:".length(),line.indexOf("公布日:")).trim());
					patent.setPublicationDate(line.substring(line.indexOf("公布日:")+"公布日:".length()).trim());
				}else if(line.indexOf("授权号:")>=0){
					patent.setGrantNumber(line.substring(line.indexOf("授权号:")+"授权号:".length(),line.indexOf("授权日:")).trim());
					patent.setGrantDate(line.substring(line.indexOf("授权日:")+"授权日:".length()).trim());
				}else if(line.indexOf("公布种类:")>=0){
					patent.setPublicationKind(line.substring(line.indexOf("公布种类:")+"公布种类:".length()).trim());
				}else if(line.indexOf("申请人:")>=0){
					patent.setApplicants(line.substring(line.indexOf("申请人:")+"申请人:".length()).trim());
				}else if(line.indexOf("发明人:")>=0){
					patent.setInventors(line.substring(line.indexOf("发明人:")+"发明人:".length()).trim());
				}else if(line.indexOf("优先权数据:")>=0){
					patent.setPriorityData(line.substring(line.indexOf("优先权数据:")+"优先权数据:".length()).trim());
				}else if(line.indexOf("标题:")>=0){
					patent.setTitle(line.substring(line.indexOf("标题:")+"标题:".length()).trim());
				}else if(line.indexOf("摘要:")>=0){
					patent.setMemo(line.substring(line.indexOf("摘要:")+"摘要:".length()).trim());
				}
			}
			patent.setIpc(doc.select("[id$=NPipc]").text());
			

			Elements elementsSrc = doc.select("[id$=header] a");
			if(elementsSrc.size()>0){
				patent.setSrcNationalBiblioData(this.baseSrc+elementsSrc.get(0).attr("href"));
				patent.setSrcDescription(this.baseSrc+elementsSrc.get(1).attr("href"));
				patent.setSrcClaims(this.baseSrc+elementsSrc.get(2).attr("href"));
				patent.setSrcDrawings(this.baseSrc+elementsSrc.get(3).attr("href"));
				patent.setSrcDocuments(this.baseSrc+elementsSrc.get(4).attr("href"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return patent;
	}
	
	//step4:插入数据库
	private void insertDb(String dbName,PatentWIPO patent){
		Connection con = null;
		PreparedStatement ps = null;
		DbConnection dbconn = null;
		try {
			dbconn = DbConnectionDao.getInstance().getMapDbConn(dbName);
			if (dbconn == null) {
				this.setTaskStatus("执行失败");
				this.setTaskMsg("获取文件导入数据库连接错误");
				return;
			}
			
			con = UtilJDBCManager.getConnection(dbconn);
//			String sqlCount="select count(1) from PATENTWIPO where APPLICATIONNUMBER='"+patent.getApplicationNumber()+"'";
//			long cnt=UtilSql.queryForCount(con, sqlCount, new Object[]{});
//			if(cnt>0){
//				this.setTaskStatus("执行成功");
//				this.setTaskMsg("已存在记录");
//				return;
//			}
			
			String sqlInsert="insert into PATENTWIPO(APPLICATIONNUMBER,APPLICATIONDATE,PUBLICATIONNUMBER," +
					"PUBLICATIONDATE,GRANTNUMBER,GRANTDATE,PUBLICATIONKIND,PCTReference,ipc,APPLICANTS," +
					"INVENTORS,PRIORITYDATA,TITLE,MEMO,SrcNationalBiblioData,SrcDescription,SrcClaims,SrcDrawings,SrcDocuments)" +
					"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			UtilSql.executeUpdate(con, sqlInsert, patent.toArray());
			this.setTaskStatus("执行成功");
			this.setTaskMsg("");
		} catch (Exception e) {
			this.setTaskStatus("执行失败");
			this.setTaskMsg("执行出错:", e);
		} finally {
			UtilSql.close(con, ps);
		}
	}
	
	public void fireTask(final String startTime, final String groupId,
			final String scheCod, final String taskOrder) {
		fireTask();
	}
	public static void main(String[] args) {
		String line="申请号: 14912010 申请日: 30.07.2014";
		String rs=line.substring(line.indexOf("申请号:")+"申请号:".length(),line.indexOf("申请日:")).trim();
		System.out.println(rs);
	}
}
