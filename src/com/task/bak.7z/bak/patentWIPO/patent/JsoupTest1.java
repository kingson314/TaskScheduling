package com.task.patentWIPO.patent;

import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import common.util.file.UtilFile;
import common.util.jdbc.UtilSql;

public class JsoupTest1 implements Runnable {
	private int threadId;
	private String url ;

	public JsoupTest1(int threadId,String url) {
		this.threadId=threadId;
		this.url = url;
	}


	@Override
	public void run() {
		PatentWIPO patent=new PatentWIPO();
		long now = System.currentTimeMillis();
		try {
			Document doc = Jsoup.connect(url).timeout(20000)
					.userAgent("Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.87 Safari/537.36")
					.ignoreContentType(true).get();

			Elements elements = doc.select("[id*=detailMainForm]").select("[id$=content]").select(".alignTop");
			for(Element ele:elements){
				System.out.println(ele.text());
			}
			String line1=elements.get(1).text();//Application Number: 14587035 Application Date: 31.12.2014
			String line2=elements.get(2).text();//Publication Number: 20160192430 Publication Date: 30.06.2016
			String line3=elements.get(3).text();//Grant Number: 09363845 Grant Date: 07.06.2016
			String line4=elements.get(4).text();//Publication Kind : B1
			String line7=elements.get(7).text();//Applicants: MOTOROLA SOLUTIONS, INC
			String line8=elements.get(8).text();//Inventors: BRUNDABAN SAHOO MIKE H. BAKER
			String line9=elements.get(9).text();//Priority Data:
			String line10=elements.get(10).text();//Title:
			String line11=elements.get(11).text();//Title://Abstract:
			
			patent.setApplicationNumber(line1.substring(line1.indexOf("Application Number:")+"Application Number:".length(),line1.indexOf("Application Date:")).trim());
			patent.setApplicationDate(line1.substring(line1.indexOf("Application Date:")+"Application Date:".length()).trim());
			patent.setPublicationNumber(line2.substring(line2.indexOf("Publication Number:")+"Publication Number:".length(),line2.indexOf("Publication Date:")).trim());
			patent.setPublicationDate(line2.substring(line2.indexOf("Publication Date:")+"Publication Date:".length()).trim());
			
			patent.setGrantNumber(line3.substring(line3.indexOf("Grant Number:")+"Grant Number:".length(),line3.indexOf("Grant Date:")).trim());
			patent.setGrantDate(line3.substring(line3.indexOf("Grant Date:")+"Grant Date:".length()).trim());
			
			patent.setPublicationKind(line4.substring(line4.indexOf("Publication Kind :")+"Publication Kind :".length()).trim());

			patent.setApplicants(line7.substring(line7.indexOf("Applicants:")+"Applicants:".length()).trim());
			patent.setInventors(line8.substring(line8.indexOf("Inventors:")+"Inventors:".length()).trim());
			patent.setPriorityData(line9.substring(line9.indexOf("Priority Data:")+"Priority Data:".length()).trim());
			patent.setTitle(line10.substring(line10.indexOf("Title:")+"Title:".length()).trim());
			patent.setMemo(line11.substring(line11.indexOf("Abstract:")+"Abstract:".length()).trim());
			patent.setIpc(doc.select("[id$=NPipc]").text());
			System.out.println(patent.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("线程"+this.threadId+"耗时:"+(System.currentTimeMillis() - now));
	}
	
	

	public static void main(String[] args) throws IOException {
		String url="http://www.kxt.com/cjrl/ajax?date=2016-11-02";
		org.jsoup.Connection conn =  Jsoup.connect(url).timeout(20000).ignoreContentType(true);
		conn.header("Accept", "application/json, text/javascript, */*; q=0.01");
		conn.header("Accept-Encoding", "gzip, deflate, sdch");
		conn.header("Accept-Language", "zh-CN,zh;q=0.8,en;q=0.6");
		conn.header("Cache-Control", "no-cache");
		conn.header("Connection", "keep-alive");
		conn.header("Cookie", "aliyungf_tc=AQAAAO8RIx2MKQcAOnxqcYgJaQnchikR; PHPSESSID=srmfnb0ou7n2ct2bulim3ung16; BAIDU_SSP_lcr=https://www.baidu.com/link?url=heT8Jm5G21sTRGuskm5QAlDdnzO5wP1hoWaiZtIzBde&wd=&eqid=f4b54bb100005977000000065823c95f; inotic=1; isound=1; selectPro=%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdt%3E%E6%95%B0%E6%8D%AE%E7%B1%BB%E5%88%AB%EF%BC%9A%3C%2Fdt%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdd%20class%3D%22on%22%3E%E9%87%91%E9%93%B6%3C%2Fdd%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdd%20class%3D%22on%22%3E%E7%9F%B3%E6%B2%B9%3C%2Fdd%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdd%20class%3D%22on%22%3E%E5%A4%96%E6%B1%87%3C%2Fdd%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20; selectImp=%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdt%3E%E9%87%8D%E8%A6%81%E6%80%A7%EF%BC%9A%3C%2Fdt%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdd%20class%3D%22on%22%3E%E9%AB%98%3C%2Fdd%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdd%20class%3D%22on%22%3E%E4%B8%AD%3C%2Fdd%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdd%20class%3D%22%22%3E%E4%BD%8E%3C%2Fdd%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20; qVHu$u9gFfh2OsWxLoh5GZ1t=fbiyZLJ3mpV_e36sg77WnJN9s5XFq3CsxtGl05SQZZ9_zaugx3uJ3IGjqKiNqZxmlmjE2sOYn2av0YfblYx6qXnSq53FinCVjI1qmo-ttax7n9DOr7l8sK_OftyBomWufc6yprGHns5-entilr2Un3uf0N2wqZpqsd6K3ICzemeWtZ5u; jumpUrl=%2Frili; CNZZDATA1255358964=476461913-1478738872-null%7C1478738872; Hm_lvt_914d75ee2c3512219b999cc5ce43eac9=1478740326; Hm_lpvt_914d75ee2c3512219b999cc5ce43eac9=1478740950");
		conn.header("Host", "www.kxt.com");
		conn.header("Referer", "http://www.kxt.com/rili");
		conn.header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36");
		conn.header("X-Requested-With", "XMLHttpRequest");
		conn.header("Pragma", "no-cache");
		Document doc = conn.get();
		System.out.println(doc.html());
	}
}
