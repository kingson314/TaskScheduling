package com.task.patentWIPO.patent;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WIPO implements Runnable {
	private static final String baseDetailUrl = "https://patentscope.wipo.int/search/en/detail.jsf?";
	private int threadId;

	public WIPO(int threadId) {
		this.threadId = threadId;
	}

	@Override
	public void run() {
		long now = System.currentTimeMillis();
		try {
			int pageSize=2;
			String url = getListUrl(pageSize);
			System.out.println(url);
			List<String> listHref = getListHref(url);
			for (String href : listHref) {
				String detailUrl = this.baseDetailUrl + href;
				getDetail(detailUrl);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("线程" + this.threadId + "耗时:"
				+ (System.currentTimeMillis() - now));
	}

	// 获取detail的href列表
	private List<String> getListHref(String url) {
		List<String> list = new ArrayList<String>();
		try {
			Document doc = Jsoup
					.connect(url)
					.timeout(20000)
					.userAgent(
							"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.87 Safari/537.36")
					.ignoreContentType(true).get();
			Elements elements = doc.select("a[id*=resultTable]");
//			System.out.println(doc.html());
			for (Element ele : elements) {
				String href = ele.attr("href");
				if (href.trim().length() > 0) {
					list.add(href.substring(href.indexOf("docId")));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	// 获取detail专利信息
	private void getDetail(String url) throws Exception {
		PatentWIPO patent=new PatentWIPO();
		long now = System.currentTimeMillis();
		Document doc = Jsoup.connect(url).timeout(20000)
				.userAgent("Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.87 Safari/537.36")
				.ignoreContentType(true).get();

		Elements elements = doc.select("[id*=detailMainForm]").select("[id$=content]").select(".alignTop");
//		for(Element ele:elements){
//			System.out.println(ele.text());
//		}
		String line1=elements.get(1).text();//Application Number: 14587035 Application Date: 31.12.2014
		String line2=elements.get(2).text();//Publication Number: 20160192430 Publication Date: 30.06.2016
		String line3=elements.get(3).text();//Grant Number: 09363845 Grant Date: 07.06.2016
		String line4=elements.get(4).text();//Publication Kind : B1
		String line7=elements.get(7).text();//Applicants: MOTOROLA SOLUTIONS, INC
		String line8=elements.get(8).text();//Inventors: BRUNDABAN SAHOO MIKE H. BAKER
		String line9=elements.get(9).text();//Priority Data:
		String line10=elements.get(10).text();//Title:
		String line11=elements.get(11).text();//Title://Abstract:
		
		patent.setApplicationNumber(line1.substring(line1.indexOf("Application Number:")+"Application Number:".length(),line1.indexOf("Application Date:")).trim());
		patent.setApplicationDate(line1.substring(line1.indexOf("Application Date:")+"Application Date:".length()).trim());
		patent.setPublicationNumber(line2.substring(line2.indexOf("Publication Number:")+"Publication Number:".length(),line2.indexOf("Publication Date:")).trim());
		patent.setPublicationDate(line2.substring(line2.indexOf("Publication Date:")+"Publication Date:".length()).trim());
		
		patent.setGrantNumber(line3.substring(line3.indexOf("Grant Number:")+"Grant Number:".length(),line3.indexOf("Grant Date:")).trim());
		patent.setGrantDate(line3.substring(line3.indexOf("Grant Date:")+"Grant Date:".length()).trim());
		
		patent.setPublicationKind(line4.substring(line4.indexOf("Publication Kind :")+"Publication Kind :".length()).trim());

		patent.setApplicants(line7.substring(line7.indexOf("Applicants:")+"Applicants:".length()).trim());
		patent.setInventors(line8.substring(line8.indexOf("Inventors:")+"Inventors:".length()).trim());
		patent.setPriorityData(line9.substring(line9.indexOf("Priority Data:")+"Priority Data:".length()).trim());
		patent.setTitle(line10.substring(line10.indexOf("Title:")+"Title:".length()).trim());
		patent.setMemo(line11.substring(line11.indexOf("Abstract:")+"Abstract:".length()).trim());
		patent.setIpc(doc.select("[id$=NPipc]").text());
		System.out.println(patent.toString());
	}

	private static String getListUrl(int pageIndex) {
		return "https://patentscope.wipo.int/search/en/result.jsf?currentNavigationRow="
				+ pageIndex
				+ "&prevCurrentNavigationRow="
				+ (pageIndex - 1)
				+ "&query=&office=&sortOption=Pub%20Date%20Desc&prevFilter=&maxRec=56518959&viewOption=All";
	}

	public static void main(String[] args) throws IOException {
		int pageSize = 1;// 目前已经确定的，暂不能修改
		// int totalRecord=100;//目前56518959 条记录
		// int pages=(int) Math.ceil(totalRecord/pageSize);
		// for(int i=1;i<=pages;i++){
		new WIPO(pageSize).run();
		// }
	}

}
